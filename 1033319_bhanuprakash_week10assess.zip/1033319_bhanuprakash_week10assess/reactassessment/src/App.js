import logo from './logo.svg';
import './App.css';
import Jsoncomponent from './Jsoncomponent';

function App() {
  return (
   <div>
    <Jsoncomponent/>
   </div>
  );
}

export default App;
