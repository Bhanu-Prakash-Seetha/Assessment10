import logo from './logo.svg';
import './App.css';
import Registration from './components/Registration';
function App() {
  return (
    <div className="App">
      <Registration/>
   
    </div>
  );
}

export default App;
