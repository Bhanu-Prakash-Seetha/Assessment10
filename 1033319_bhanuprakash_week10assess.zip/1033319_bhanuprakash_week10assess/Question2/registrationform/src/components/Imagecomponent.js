import React from "react";
class Imagecomponent extends React.Component{
    render(){
        return(
            <div>
                <img src="https://img.freepik.com/premium-vector/pharmacy-building-isolated-white_180264-152.jpg?size=626&ext=jpg&ga=GA1.1.1826414947.1699833600&semt=ais" alt="image" />
            </div>
        )
    }
}
export default Imagecomponent;