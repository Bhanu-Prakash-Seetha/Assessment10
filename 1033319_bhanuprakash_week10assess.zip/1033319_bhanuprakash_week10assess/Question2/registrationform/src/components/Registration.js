import React from "react";
import "./Registration.css"
class RegisterForm extends React.Component {
    constructor() {
        super();
        this.state = {
            fields: {},
            errors: {}
        }
        this.handleChange = this.handleChange.bind(this);
        this.formsubmit = this.formsubmit.bind(this);
    }
    handleChange(e) {
        let fields = this.state.fields;
        fields[e.target.name] = e.target.value;
        this.setState({
            fields
        })
    }
    formsubmit(e) {
        e.preventDefault();
        if (this.validate()) {
            alert("Successfully registered");
        }
    }
    validate() {
        let fields = this.state.fields;
        let errors = {};
        let fvalid = true;
        if (!fields["name"]) {
            fvalid = false;
            errors["name"] ="*Name cannot be empty";
        }
        if (!fields["mobileno"]) {
            fvalid = false;
            errors["mobileno"] = "*Mobile number cannot be empty!";
        }
        if (!fields["Address"]) {
            fvalid = false;
            errors["Address"] = "*Address should not be empty";
        }
        if(!fields["vendorid"]){
            fvalid=false;
            errors["vendorid"] = "*Vendor ID field cannot be empty!."
        }  
        if(!fields["password"]){
            fvalid = false;
            errors["password"] = "*Password cannot be empty!";
        }
        if(fields["password"]){
            var pattern = new RegExp(/[@/.$^&]/);
            if(!pattern.test(fields["password"])){
                fvalid = false;
                errors["password"] = "*Passwords should contains special characters(@,/,& etc)."
            }
        }
        if(!fields["rpassword"]){
            fvalid = false;
            errors["rpassword"] = "*Password cannot be empty!";
        }
        if(fields["password"]!=fields["rpassword"]){
            fvalid = false;
            errors["rpassword"] = "the password fields should match!";
        }
        this.setState({
            errors: errors
        });
        return fvalid;
    }
    render() {
        return (
            <div id="formcolor">
                <div id="register">
                    <form method="post" id="register-Form" name="userRegistrationform" onSubmit={this.formsubmit}>
                       <h2>Register New Vendor</h2>
                        <input type="text" placeholder="Enter Name" name="name" value={this.state.fields.name} onChange={this.handleChange}  className="bottomcolor"/>
                        <div className="errorvalue">{this.state.errors.name}</div>
                      
                        <input type="tel" placeholder="Enter Phone Number" name="mobileno" value={this.state.fields.mobileno} onChange={this.handleChange} className="bottomcolor"/>
                        <div className="errorvalue">{this.state.errors.mobileno}</div>
                      
                        <input type="text" placeholder="Enter Address" name="address" value={this.state.fields.address} onChange={this.handleChange} className="bottomcolor"/>
                        <div className="errorvalue">{this.state.errors.address}</div>

                        <input type="text" placeholder="Enter Vendor ID" name="vendorid" value={this.state.fields.vendorid} onChange={this.handleChange} className="bottomcolor"/>
                        <div className="errorvalue">{this.state.errors.vendorid}</div>

                        <input type="password" placeholder="Enter Password" name="password" value={this.state.fields.password} onChange={this.handleChange} className="bottomcolor"/>
                        <div className="errorvalue">{this.state.errors.password}</div>

                        <input type="password" placeholder="Retype Password" name="rpassword" value={this.state.fields.rpassword} onChange={this.handleChange} className="bottomcolor"/>
                        <div className="errorvalue">{this.state.errors.rpassword}</div>
                        <input type="submit" value="Submit" className="btn" />
                    </form>
                </div>
                <img src="https://cdni.iconscout.com/illustration/premium/thumb/pharmacy-store-5312778-4432033.png" alt="image"/>
            </div>
        )
    }
}
export default RegisterForm;