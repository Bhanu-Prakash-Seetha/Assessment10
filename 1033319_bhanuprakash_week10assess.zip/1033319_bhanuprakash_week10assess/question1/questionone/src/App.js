import logo from './logo.svg';
import './App.css';
import CircularProgress from '@mui/joy/CircularProgress';

function App() {
  return (
    <div className="App">
      <header className="App-header">
       <div id='divimg'><img src={logo} className="App-logo" alt="logo" /><h4>React</h4></div> 
        <h1><b>LOADING</b> <br/> <b>SCREEN</b> <br/><b>REACTJS</b></h1>
        <div id='spinbg'><CircularProgress  id="spinner"/></div>
        
      </header>
      
    </div>
  );
}

export default App;
